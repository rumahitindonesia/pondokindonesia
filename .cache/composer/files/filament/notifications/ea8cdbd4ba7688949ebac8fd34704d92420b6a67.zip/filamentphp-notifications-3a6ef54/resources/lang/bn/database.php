<?php

return [

    'modal' => [

        'heading' => 'বিজ্ঞপ্তি',

        'actions' => [

            'clear' => [
                'label' => 'পরিষ্কার',
            ],

            'mark_all_as_read' => [
                'label' => 'পড়া হয়েছে',
            ],

        ],

        'empty' => [
            'heading' => 'কোন বিজ্ঞপ্তি নেই',
            'description' => 'পরে আবার চেষ্টা করুন',
        ],

    ],

];
