<?php

return [

    'single' => [

        'label' => 'Шинэ :label',

        'modal' => [

            'heading' => 'Шинэ :label',

            'actions' => [

                'create' => [
                    'label' => 'Шинэ',
                ],

                'create_another' => [
                    'label' => 'Хадгалаад & дахин шинийг үүсгэх',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Үүсэв',
            ],

        ],

    ],

];
