<?php

return [

    'single' => [

        'label' => 'Կրկնօրինակել',

        'modal' => [

            'heading' => 'Կրկնօրինակել :labelը',

            'actions' => [

                'replicate' => [
                    'label' => 'Կրկնօրինակել',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Գրառումը կրկնօրինակվել է',
            ],

        ],

    ],

];
