<?php

return [

    'trigger' => [
        'label' => 'Accions',
    ],

];
