<?php

return [

    'trigger' => [
        'label' => 'Műveletek',
    ],

];
