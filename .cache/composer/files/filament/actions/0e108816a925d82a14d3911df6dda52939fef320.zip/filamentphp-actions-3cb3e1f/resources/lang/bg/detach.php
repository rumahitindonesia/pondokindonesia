<?php

return [

    'single' => [

        'label' => 'Разкачи',

        'modal' => [

            'heading' => 'Разкачи :label',

            'actions' => [

                'detach' => [
                    'label' => 'Разкачи',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Разкачен',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Разкачи избраните',

        'modal' => [

            'heading' => 'Разкачи избраните :label',

            'actions' => [

                'detach' => [
                    'label' => 'Разкачи',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Разкачени',
            ],

        ],

    ],

];
