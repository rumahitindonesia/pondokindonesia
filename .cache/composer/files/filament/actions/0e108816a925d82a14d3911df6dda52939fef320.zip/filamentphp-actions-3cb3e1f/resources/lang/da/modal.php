<?php

return [

    'confirmation' => 'Er du sikker på, at du gerne vil gøre dette?',

    'actions' => [

        'cancel' => [
            'label' => 'Annuller',
        ],

        'confirm' => [
            'label' => 'Bekræft',
        ],

        'submit' => [
            'label' => 'Send',
        ],

    ],

];
