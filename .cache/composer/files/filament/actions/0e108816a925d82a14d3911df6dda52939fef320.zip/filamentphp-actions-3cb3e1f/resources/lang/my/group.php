<?php

return [

    'trigger' => [
        'label' => 'လုပ်ဆောင်ချက်များ',
    ],

];
