<?php

return [

    'single' => [

        'label' => 'Irrota',

        'modal' => [

            'heading' => 'Irrota :label',

            'actions' => [

                'detach' => [
                    'label' => 'Irrota',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Irrotettu',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Irrota valitut',

        'modal' => [

            'heading' => 'Irrota valitut :label',

            'actions' => [

                'detach' => [
                    'label' => 'Irrota valitut',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Irrotettu',
            ],

        ],

    ],

];
