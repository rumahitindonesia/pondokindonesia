<?php

return [

    'single' => [

        'label' => 'ផ្តាច់ខ្លួន',

        'modal' => [

            'heading' => 'ផ្តាច់ខ្លួន :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'ផ្តាច់ខ្លួន',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'បែកគ្នា។',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'បានជ្រើសរើសផ្តាច់មុខ',

        'modal' => [

            'heading' => 'បានជ្រើសរើសផ្តាច់មុខ :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'ផ្តាច់ខ្លួន',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'បែកគ្នា។',
            ],

        ],

    ],

];
