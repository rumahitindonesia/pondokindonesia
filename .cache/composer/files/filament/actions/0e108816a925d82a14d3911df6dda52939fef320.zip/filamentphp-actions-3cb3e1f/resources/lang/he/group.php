<?php

return [

    'trigger' => [
        'label' => 'פעולות',
    ],

];
