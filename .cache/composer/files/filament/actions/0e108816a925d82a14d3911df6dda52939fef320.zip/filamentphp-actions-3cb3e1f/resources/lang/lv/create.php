<?php

return [

    'single' => [

        'label' => 'Jauns :label',

        'modal' => [

            'heading' => 'Izveidot :label',

            'actions' => [

                'create' => [
                    'label' => 'Izveidot',
                ],

                'create_another' => [
                    'label' => 'Izveidot & izveidot citu',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Izveidots',
            ],

        ],

    ],

];
