<?php

return [

    'single' => [

        'label' => 'جدا کردن',

        'modal' => [

            'heading' => 'جدا کردن :label',

            'actions' => [

                'detach' => [
                    'label' => 'جدا کردن',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'جدا شد',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'جدا کردن انتخاب شده',

        'modal' => [

            'heading' => 'جدا کردن :label انتخاب شده',

            'actions' => [

                'detach' => [
                    'label' => 'جدا کردن انتخاب شده',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'جدا شد',
            ],

        ],

    ],

];
