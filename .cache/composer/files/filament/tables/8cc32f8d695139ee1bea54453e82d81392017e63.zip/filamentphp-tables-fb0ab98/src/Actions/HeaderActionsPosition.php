<?php

namespace Filament\Tables\Actions;

enum HeaderActionsPosition
{
    case Adaptive;
    case Bottom;
}
