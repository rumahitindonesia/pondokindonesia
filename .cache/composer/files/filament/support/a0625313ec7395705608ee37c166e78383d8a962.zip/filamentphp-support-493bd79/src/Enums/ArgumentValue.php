<?php

namespace Filament\Support\Enums;

enum ArgumentValue
{
    case Default;
}
