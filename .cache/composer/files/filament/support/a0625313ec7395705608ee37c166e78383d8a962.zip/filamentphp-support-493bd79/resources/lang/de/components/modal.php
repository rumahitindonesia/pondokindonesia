<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Schließen',
        ],

    ],

];
