<?php

return [

    'messages' => [
        'uploading_file' => 'Fájl feltöltése...',
    ],

];
