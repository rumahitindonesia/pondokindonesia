<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Stäng',
        ],

    ],

];
