<?php

return [

    'messages' => [
        'copied' => 'تم النسخ',
    ],

];
