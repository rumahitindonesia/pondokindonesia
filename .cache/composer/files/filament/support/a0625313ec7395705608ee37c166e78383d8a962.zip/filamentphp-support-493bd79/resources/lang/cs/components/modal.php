<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Zavřít',
        ],

    ],

];
