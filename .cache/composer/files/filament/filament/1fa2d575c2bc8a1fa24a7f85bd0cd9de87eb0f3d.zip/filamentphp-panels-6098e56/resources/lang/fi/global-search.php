<?php

return [

    'field' => [
        'label' => 'Globaali haku',
        'placeholder' => 'Hae',
    ],

    'no_results_message' => 'Hakutuloksia ei löytynyt.',

];
