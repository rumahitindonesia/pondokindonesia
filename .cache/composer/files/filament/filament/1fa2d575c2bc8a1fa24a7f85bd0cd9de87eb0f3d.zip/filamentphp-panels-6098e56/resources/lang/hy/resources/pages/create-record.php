<?php

return [

    'title' => 'Ստեղծել :label',

    'breadcrumb' => 'Ստեղծել',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Չեղարկել',
            ],

            'create' => [
                'label' => 'Ստեղծել',
            ],

            'create_another' => [
                'label' => 'Ստեղծել և ստեղծել մեկ այլ',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'Ստեղծվել է',
        ],

    ],

];
