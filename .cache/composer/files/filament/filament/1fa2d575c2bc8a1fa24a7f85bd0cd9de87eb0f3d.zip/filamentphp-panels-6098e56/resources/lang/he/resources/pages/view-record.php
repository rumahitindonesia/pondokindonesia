<?php

return [

    'title' => 'תצוגת :label',

    'breadcrumb' => 'הצגה',

    'content' => [

        'tab' => [
            'label' => 'הצגה',
        ],

    ],

];
