<?php

return [

    'field' => [
        'label' => 'Ümumi axtarış',
        'placeholder' => 'Axtar',
    ],

    'no_results_message' => 'Nəticə tapılmadı.',

];
