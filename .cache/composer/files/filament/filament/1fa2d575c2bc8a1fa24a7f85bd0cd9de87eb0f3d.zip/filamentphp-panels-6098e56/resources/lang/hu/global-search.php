<?php

return [

    'field' => [
        'label' => 'Globális keresés',
        'placeholder' => 'Keresés',
    ],

    'no_results_message' => 'Nincs találat.',

];
