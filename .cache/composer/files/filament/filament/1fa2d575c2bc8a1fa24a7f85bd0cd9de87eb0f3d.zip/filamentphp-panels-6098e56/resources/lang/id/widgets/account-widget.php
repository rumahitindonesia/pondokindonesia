<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Keluar',
        ],

    ],

    'welcome' => 'Selamat Datang',

];
