<?php

return [

    'title' => 'डैशबोर्ड',

];
