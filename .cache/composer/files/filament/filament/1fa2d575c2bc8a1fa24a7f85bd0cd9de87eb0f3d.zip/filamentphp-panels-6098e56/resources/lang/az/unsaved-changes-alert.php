<?php

return [

    'body' => 'Saxlanılmamış dəyişikliklər var. Bu səhifədən çıxmaq istədiyinizə əminsiniz?',

];
