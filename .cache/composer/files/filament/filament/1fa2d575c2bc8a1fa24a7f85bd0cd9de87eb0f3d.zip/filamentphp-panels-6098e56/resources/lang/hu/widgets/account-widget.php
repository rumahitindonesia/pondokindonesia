<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Kijelentkezés',
        ],

    ],

    'welcome' => 'Üdvözlünk',

];
