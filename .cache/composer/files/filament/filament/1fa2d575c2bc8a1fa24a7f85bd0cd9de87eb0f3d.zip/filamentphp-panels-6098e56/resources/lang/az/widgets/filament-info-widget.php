<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dokumentasiya',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
