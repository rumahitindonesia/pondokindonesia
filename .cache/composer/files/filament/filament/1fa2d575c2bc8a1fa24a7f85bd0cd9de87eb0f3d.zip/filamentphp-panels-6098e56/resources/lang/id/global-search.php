<?php

return [

    'field' => [
        'label' => 'Pencarian global',
        'placeholder' => 'Cari',
    ],

    'no_results_message' => 'Pencarian tidak ditemukan.',

];
