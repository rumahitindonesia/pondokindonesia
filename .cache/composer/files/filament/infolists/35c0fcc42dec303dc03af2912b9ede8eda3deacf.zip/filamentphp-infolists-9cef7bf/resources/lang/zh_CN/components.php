<?php

return [

    'text_entry' => [
        'more_list_items' => '还有 :count 条记录',
    ],

];
