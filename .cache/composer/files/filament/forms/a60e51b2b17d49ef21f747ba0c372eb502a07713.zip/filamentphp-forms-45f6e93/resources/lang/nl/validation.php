<?php

return [

    'distinct' => [
        'must_be_selected' => 'Minstens één :attribute veld moet worden geselecteerd.',
        'only_one_must_be_selected' => 'Slechts één :attribute veld mag worden geselecteerd.',
    ],

];
