<?php

return [

    'distinct' => [
        'must_be_selected' => 'Πρέπει να επιλεγεί τουλάχιστον ένα πεδίο :attribute.',
        'only_one_must_be_selected' => 'Μόνο ένα πεδίο :attribute πρέπει να επιλεγεί.',
    ],

];
