<?php

namespace Filament\Forms\Components\Contracts;

interface CanConcealComponents
{
    public function canConcealComponents(): bool;
}
