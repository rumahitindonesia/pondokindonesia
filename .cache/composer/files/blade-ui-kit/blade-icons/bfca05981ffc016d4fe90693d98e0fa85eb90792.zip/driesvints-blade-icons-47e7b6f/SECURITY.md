# Security Policy

**PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, [SEE BELOW](#reporting-a-vulnerability).**

## Supported Versions

Only the latest major version receives security fixes.

## Reporting a Vulnerability

If you discover a security vulnerability, please send an email to Dries Vints at <dries@vints.be>. All security vulnerabilities will be promptly addressed.
