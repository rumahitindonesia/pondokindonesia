__author__ = "Inada Naoki <songofacandy@gmail.com>"
__version__ = "2.2.8"
version_info = (2, 2, 8, "final", 0)
