<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GroqService
{
    protected string $apiKey;
    protected string $apiUrl = 'https://api.groq.com/openai/v1/chat/completions';
    protected string $model = 'llama-3.3-70b-versatile';

    public function __construct()
    {
        $this->apiKey = Setting::get('groq_api_key') ?? config('services.groq.key') ?? '';
    }

    public function generatePostContent(string $prompt): ?array
    {
        Log::info('GroqService: Generating content for prompt', ['prompt' => $prompt]);

        if (!$this->apiKey) {
            Log::error('GroqService: API Key is missing.');
            return null;
        }

        try {
            $response = Http::withToken($this->apiKey)->post($this->apiUrl, [
                'model' => $this->model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => "You are an expert blog writer and SEO specialist. Return the result in JSON format with keys: 'title', 'content' (HTML), 'meta_title' (max 60 chars), 'meta_description' (max 160 chars), and 'meta_keywords' (comma separated). The content should be engaging, well-structured (using h2, h3, p tags), and at least 300 words."
                    ],
                    [
                        'role' => 'user',
                        'content' => "Write a blog post about: {$prompt}"
                    ]
                ],
                'response_format' => ['type' => 'json_object'],
                'temperature' => 0.7,
            ]);

            if ($response->successful()) {
                $data = $response->json();
                Log::info('GroqService: API Response success', ['data' => $data]);
                
                $content = $data['choices'][0]['message']['content'] ?? null;
                if ($content) {
                    return json_decode($content, true);
                }
            }

            Log::error('GroqService: API Error', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);

            return null;
        } catch (\Throwable $e) {
            Log::error('GroqService: Exception', ['message' => $e->getMessage()]);
            return null;
        }
    }

    public function generateFundraisingStory(string $topic): ?array
    {
        Log::info('GroqService: Generating fundraising story for topic', ['topic' => $topic]);

        if (!$this->apiKey) {
            Log::error('GroqService: API Key is missing.');
            return null;
        }

        try {
            $response = Http::withToken($this->apiKey)->post($this->apiUrl, [
                'model' => $this->model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => "You are an expert fundraising copywriter. Your goal is to write a highly persuasive and emotional fundraising story using the AIDA (Attention, Interest, Desire, Action) formula. Return the result in JSON format with keys: 'title' and 'story' (HTML format with p, h2, h3 tags). Use Indonesian language."
                    ],
                    [
                        'role' => 'user',
                        'content' => "Write a fundraising story for: {$topic}"
                    ]
                ],
                'response_format' => ['type' => 'json_object'],
                'temperature' => 0.8,
            ]);

            if ($response->successful()) {
                $data = $response->json();
                $content = $data['choices'][0]['message']['content'] ?? null;
                if ($content) {
                    return json_decode($content, true);
                }
            }

            return null;
        } catch (\Throwable $e) {
            Log::error('GroqService: Exception', ['message' => $e->getMessage()]);
            return null;
        }
    }

    public function generatePPDBLandingPage(string $title, string $description): ?array
    {
        Log::info('GroqService: Generating PPDB landing page for', ['title' => $title]);

        if (!$this->apiKey) {
            Log::error('GroqService: API Key is missing.');
            return null;
        }

        try {
            $response = Http::withToken($this->apiKey)->post($this->apiUrl, [
                'model' => $this->model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => "You are an expert SaaS landing page copywriter specializing in Islamic Education. Your goal is to generate a highly professional and persuasive landing page for a Pondok Pesantren's PPDB (Penerimaan Peserta Didik Baru) campaign. The content should use the AIDA formula and highlight the benefits of modern management. Return the result in JSON format with keys: 'headline', 'subheadline', 'content_html' (including sections for Why Us, Facilities, and Programs, using p, h2, h3, li tags). Use Indonesian language (Bahasa Indonesia formal & santun)."
                    ],
                    [
                        'role' => 'user',
                        'content' => "Generate PPDB landing page content for: Title: {$title}, Description: {$description}"
                    ]
                ],
                'response_format' => ['type' => 'json_object'],
                'temperature' => 0.7,
            ]);

            if ($response->successful()) {
                $data = $response->json();
                $content = $data['choices'][0]['message']['content'] ?? null;
                if ($content) {
                    return json_decode($content, true);
                }
            }

            return null;
        } catch (\Throwable $e) {
            Log::error('GroqService: Exception', ['message' => $e->getMessage()]);
            return null;
        }
    }
}
