<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class UnsplashService
{
    protected string $accessKey;
    protected string $baseUrl = 'https://api.unsplash.com';

    public function __construct()
    {
        // Check TenantSetting first, fallback to env
        $this->accessKey = \App\Models\TenantSetting::get('unsplash_access_key') ?? env('UNSPLASH_ACCESS_KEY', '');
    }

    public function isEnabled(): bool
    {
        return !empty($this->accessKey);
    }

    /**
     * Search for images based on query
     */
    public function searchImages(string $query, int $perPage = 10): array
    {
        if (!$this->isEnabled()) {
            return [];
        }

        try {
            $response = Http::get("{$this->baseUrl}/search/photos", [
                'client_id' => $this->accessKey,
                'query' => $query,
                'per_page' => $perPage,
                'orientation' => 'landscape',
            ]);

            if ($response->successful()) {
                return $response->json()['results'] ?? [];
            }

            return [];
        } catch (\Exception $e) {
            \Log::error('Unsplash API Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Download and save image from Unsplash URL
     */
    public function downloadImage(string $imageUrl, string $photographerName = 'unsplash'): ?string
    {
        try {
            // Download image
            $imageContent = Http::get($imageUrl)->body();
            
            // Generate unique filename
            $filename = 'campaigns/' . Str::random(40) . '.jpg';
            
            // Save to storage
            Storage::disk('public')->put($filename, $imageContent);
            
            return $filename;
        } catch (\Exception $e) {
            \Log::error('Unsplash Download Error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get a random image for campaign based on type
     */
    public function getRandomCampaignImage(string $campaignType = 'ppdb', string $customQuery = null): ?array
    {
        $query = $customQuery ?? $this->getDefaultQuery($campaignType);
        $images = $this->searchImages($query, 1);

        if (empty($images)) {
            return null;
        }

        $image = $images[0];
        
        return [
            'url' => $image['urls']['regular'] ?? null,
            'download_url' => $image['urls']['raw'] ?? null,
            'photographer' => $image['user']['name'] ?? 'Unknown',
            'photographer_url' => $image['user']['links']['html'] ?? null,
            'description' => $image['description'] ?? $image['alt_description'] ?? '',
        ];
    }

    /**
     * Get default search query based on campaign type
     */
    protected function getDefaultQuery(string $type): string
    {
        return match($type) {
            'ppdb' => 'islamic school students education',
            'fundraising' => 'charity donation helping hands',
            default => 'education learning',
        };
    }

    /**
     * Download and save campaign image
     */
    public function downloadCampaignImage(string $campaignType = 'ppdb', string $customQuery = null): ?string
    {
        $imageData = $this->getRandomCampaignImage($campaignType, $customQuery);
        
        if (!$imageData || !$imageData['download_url']) {
            return null;
        }

        return $this->downloadImage($imageData['download_url'], $imageData['photographer']);
    }
}
