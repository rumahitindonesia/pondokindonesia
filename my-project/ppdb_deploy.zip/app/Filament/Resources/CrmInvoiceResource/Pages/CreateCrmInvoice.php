<?php

namespace App\Filament\Resources\CrmInvoiceResource\Pages;

use App\Filament\Resources\CrmInvoiceResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCrmInvoice extends CreateRecord
{
    protected static string $resource = CrmInvoiceResource::class;
}
