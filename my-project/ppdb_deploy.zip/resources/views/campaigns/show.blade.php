<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $campaign->meta_title ?: $campaign->title }} - {{ $tenant->name }}</title>
    <meta name="description" content="{{ $campaign->meta_description ?: Str::limit(strip_tags($campaign->landing_page_content), 160) }}">
    <meta name="keywords" content="{{ $campaign->seo_keywords }}">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:title" content="{{ $campaign->meta_title ?: $campaign->title }}">
    <meta property="og:description" content="{{ $campaign->meta_description ?: Str::limit(strip_tags($campaign->landing_page_content), 160) }}">
    @if($campaign->image)
    <meta property="og:image" content="{{ asset('storage/' . $campaign->image) }}">
    @endif

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="{{ url()->current() }}">
    <meta property="twitter:title" content="{{ $campaign->meta_title ?: $campaign->title }}">
    <meta property="twitter:description" content="{{ $campaign->meta_description ?: Str::limit(strip_tags($campaign->landing_page_content), 160) }}">
    @if($campaign->image)
    <meta property="twitter:image" content="{{ asset('storage/' . $campaign->image) }}">
    @endif
    <script src="https://cdn.tailwindcss.com?plugins=typography"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        /* Manual fallback if prose fails */
        .campaign-content h1 { font-size: 2.25rem; font-weight: 700; margin-bottom: 1.5rem; color: #111827; }
        .campaign-content h2 { font-size: 1.5rem; font-weight: 600; margin-top: 2.5rem; margin-bottom: 1rem; color: #1f2937; border-bottom: 1px solid #e5e7eb; padding-bottom: 0.5rem; }
        .campaign-content h3 { font-size: 1.25rem; font-weight: 600; margin-top: 1.5rem; margin-bottom: 0.75rem; color: #4338ca; }
        .campaign-content p { color: #4b5563; margin-bottom: 1rem; line-height: 1.625; }
        .campaign-content ul { list-style-type: disc; list-style-position: inside; margin-bottom: 1rem; color: #4b5563; }
        .campaign-content li { margin-left: 1rem; margin-bottom: 0.5rem; }
    </style>
</head>
<body class="bg-gray-50 antialiased">
    <!-- Navbar -->
    <nav class="bg-white shadow-sm sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <div class="flex-shrink-0 flex items-center">
                    <span class="text-xl font-bold text-indigo-600">{{ $tenant->name }}</span>
                </div>
                <div>
                    <a href="#register" class="bg-indigo-600 text-white px-5 py-2 rounded-full font-semibold hover:bg-indigo-700 transition">Daftar Sekarang</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <!-- Content Area -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-2xl shadow-sm p-8 lg:p-12 mb-8">
                    <div class="campaign-content prose prose-indigo max-w-none">
                        {!! $campaign->landing_page_content !!}
                    </div>
                </div>
            </div>

            <!-- Sidebar / Form -->
            <div class="lg:col-span-1">
                <div class="sticky top-24">
                    <div id="register" class="bg-white rounded-2xl shadow-lg border border-indigo-100 overflow-hidden">
                        <div class="bg-indigo-600 px-6 py-4 text-white">
                            <h3 class="text-xl font-bold">Formulir Pendaftaran</h3>
                            <p class="text-sm text-indigo-100 italic">Mulai langkah sukses santri hari ini</p>
                        </div>
                        
                        <form action="{{ route('campaign.register', [$tenant->slug, $campaign->slug]) }}" method="POST" class="p-6 space-y-4">
                            @csrf
                            @if(request()->has('aff_id'))
                                <input type="hidden" name="aff_id" value="{{ request('aff_id') }}">
                            @endif

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap Santri</label>
                                <input type="text" name="name" required class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="Contoh: Muhammad Ali">
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Email Orang Tua</label>
                                <input type="email" name="email" required class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="email@contoh.com">
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Nomor WhatsApp</label>
                                <input type="text" name="whatsapp" required class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="0812xxxxxxxx">
                                <p class="text-[10px] text-gray-400 mt-1">*Pastikan nomor aktif untuk menerima notifikasi</p>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Asal Sekolah (Opsional)</label>
                                <input type="text" name="institution_name" class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="Contoh: SMP Negeri 1">
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Pesan / Pertanyaan (Opsional)</label>
                                <textarea name="message" rows="3" class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" placeholder="Tanyakan hal yang ingin Anda ketahui..."></textarea>
                            </div>

                            <button type="submit" class="w-full bg-indigo-600 text-white font-bold py-3 rounded-lg hover:bg-indigo-700 shadow-md transform hover:-translate-y-0.5 transition flex items-center justify-center">
                                Daftarkan Sekarang
                                <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
                            </button>
                            
                            <p class="text-center text-xs text-gray-400 mt-4">
                                Data Anda aman dan hanya digunakan untuk keperluan PPDB.
                            </p>
                        </form>
                    </div>

                    <!-- Fee Info Card -->
                    <div class="mt-6 bg-gradient-to-br from-white to-indigo-50 rounded-2xl p-6 border border-indigo-100">
                        <h4 class="font-bold text-gray-800 mb-3 flex items-center">
                            <svg class="w-5 h-5 mr-2 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            Informasi Biaya
                        </h4>
                        <div class="space-y-3">
                            <div class="flex justify-between items-center text-sm">
                                <span class="text-gray-600">Pendaftaran</span>
                                <span class="font-semibold text-gray-900 italic">Rp {{ number_format($campaign->registration_fee) }}</span>
                            </div>
                            <div class="flex justify-between items-center text-sm">
                                <span class="text-gray-600">Pendidikan</span>
                                <span class="font-semibold text-gray-900 italic">Rp {{ number_format($campaign->education_fee) }}</span>
                            </div>
                            <div class="border-t pt-2 mt-2 flex justify-between items-center font-bold text-indigo-600">
                                <span>Total Estimasi</span>
                                <span>Rp {{ number_format($campaign->registration_fee + $campaign->education_fee) }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12 mt-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center italic">
            <p>&copy; {{ date('Y') }} {{ $tenant->name }}. Dikelola dengan Sistem Manajemen Pesantren Modern.</p>
        </div>
    </footer>
</body>
</html>
