from django.apps import AppConfig


class TenantsConfig(AppConfig):
    name = 'tenants'
