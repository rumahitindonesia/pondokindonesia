from django.db import models
import threading

_thread_locals = threading.local()

def get_current_tenant():
    return getattr(_thread_locals, 'tenant', None)

def set_current_tenant(tenant):
    _thread_locals.tenant = tenant

class TenantManager(models.Manager):
    def __init__(self, include_global=False):
        super().__init__()
        self.include_global = include_global

    def get_queryset(self):
        qs = super().get_queryset()
        tenant = get_current_tenant()
        if tenant:
            if self.include_global:
                return qs.filter(models.Q(tenant=tenant) | models.Q(tenant__isnull=True))
            return qs.filter(tenant=tenant)
        return qs

class TenantAwareModel(models.Model):
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE, null=True, blank=True)
    
    objects = TenantManager()
    global_objects = TenantManager(include_global=True)
    all_objects = models.Manager()

    class Meta:
        abstract = True

class APISetting(TenantAwareModel):
    objects = TenantManager(include_global=True)
    class Category(models.TextChoices):
        WHATSAPP = 'WHATSAPP', 'WhatsApp (StarSender)'
        AI = 'AI', 'Artificial Intelligence (Gemini/Groq)'
        MEDIA = 'MEDIA', 'Media/Assets (Unsplash)'
        OTHER = 'OTHER', 'Other Integrations'

    key_name = models.SlugField(max_length=100)
    value = models.TextField(help_text="Clear text for now, can be encrypted later.")
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.OTHER)
    is_active = models.BooleanField(default=True)
    description = models.CharField(max_length=255, blank=True)

    class Meta:
        unique_together = ('key_name', 'tenant')
        verbose_name = "API Setting"
        verbose_name_plural = "API Settings"

    def __str__(self):
        scope = "Global" if not self.tenant else f"Tenant: {self.tenant}"
        return f"{self.key_name} ({scope})"
