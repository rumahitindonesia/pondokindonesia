from django.contrib import admin
from django.db import models
from unfold.admin import ModelAdmin
from .models import get_current_tenant, APISetting

class BaseTenantAdmin(ModelAdmin):
    def save_model(self, request, obj, form, change):
        tenant = getattr(request, 'tenant', None)
        if tenant and hasattr(obj, 'tenant'):
            obj.tenant = tenant
        super().save_model(request, obj, form, change)

@admin.register(APISetting)
class APISettingAdmin(ModelAdmin):
    list_display = ('key_name', 'category', 'scope', 'is_active')
    list_filter = ('category', 'is_active', 'tenant')
    search_fields = ('key_name', 'description')

    def scope(self, obj):
        return "Global" if not obj.tenant else f"Tenant: {obj.tenant}"
    scope.short_description = 'Scope'

    def get_queryset(self, request):
        tenant = getattr(request, 'tenant', None)
        if tenant:
            # Use global_objects to include global settings
            return APISetting.global_objects.all()
        return super().get_queryset(request)

    def save_model(self, request, obj, form, change):
        tenant = getattr(request, 'tenant', None)
        if tenant:
            obj.tenant = tenant
        super().save_model(request, obj, form, change)
