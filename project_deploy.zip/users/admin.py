from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.db import models
from unfold.admin import ModelAdmin
from .models import User, Role
from core.admin import BaseTenantAdmin

@admin.register(Role)
class RoleAdmin(BaseTenantAdmin, ModelAdmin):
    list_display = ('name', 'slug', 'scope', 'is_system')
    list_filter = ('tenant', 'is_system')
    search_fields = ('name', 'slug')

    def scope(self, obj):
        return "Global" if not obj.tenant else f"Tenant: {obj.tenant}"
    scope.short_description = 'Scope'

    def get_queryset(self, request):
        tenant = getattr(request, 'tenant', None)
        if tenant:
            return Role.global_objects.all()
        return super().get_queryset(request)

@admin.register(User)
class UserAdmin(BaseTenantAdmin, BaseUserAdmin, ModelAdmin):
    list_display = ('username', 'email', 'role', 'tenant', 'is_staff')
    list_filter = ('role', 'is_staff', 'is_superuser', 'is_active', 'groups')
    fieldsets = BaseUserAdmin.fieldsets + (
        ('SaaS Info', {'fields': ('role', 'tenant')}),
    )
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ('SaaS Info', {'fields': ('role', 'tenant')}),
    )

    def get_queryset(self, request):
        tenant = getattr(request, 'tenant', None)
        # Central Admin: Show all system users (tenant=NULL)
        if not tenant:
            return User.all_objects.filter(tenant__isnull=True)
        # Tenant Admin: The default 'objects' (TenantUserManager) 
        # already filters strictly by the current tenant.
        return super().get_queryset(request)

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "role":
            tenant = getattr(request, 'tenant', None)
            if tenant:
                # Filter roles for tenant admins:
                # 1. Roles belonging to this specific tenant
                # 2. Global roles (tenant=None) but EXCLUDING critical SaaS Admin roles
                kwargs["queryset"] = Role.global_objects.filter(
                    models.Q(tenant=tenant) | 
                    models.Q(tenant__isnull=True)
                ).exclude(slug='saas_admin')
        
        # Also restrict the tenant field if present in the form (unlikely for tenant admins, but safe)
        if db_field.name == "tenant":
            tenant = getattr(request, 'tenant', None)
            if tenant:
                kwargs["queryset"] = db_field.related_model.objects.filter(id=tenant.id)

        return super().formfield_for_foreignkey(db_field, request, **kwargs)
